package app

// Version specifies the current version of the application.
// The value of this variable is replaced with the latest git tag
// by "make" while building or running the application.
var Version = "1.0"
